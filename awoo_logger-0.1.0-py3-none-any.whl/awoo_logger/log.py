# Custom Logger Using Loguru

import logging
import uvicorn
import sys, os
from pathlib import Path
from loguru import logger
from copy import copy
import notifiers
import json



from notifiers.logging import NotificationHandler

class InterceptHandler(logging.Handler):
    loglevel_mapping = {
        50: 'CRITICAL',
        40: 'ERROR',
        30: 'WARNING',
        20: 'INFO',
        10: 'DEBUG',
        0: 'NOTSET',
    }

    def emit(self, record):
        (
            client_addr,
            method,
            full_path,
            http_version,
            status_code,
        ) = (None,None,None,None,None)
        try:
            level = logger.level(record.levelname).name
        except AttributeError:
            level = self.loglevel_mapping[record.levelno]

        frame, depth = logging.currentframe(), 2
        while frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1
        log = logger.bind(app_name=os.getenv("APP_NAME"),log_type="ACCESS_LOG",client_addr=client_addr,method=method,status_code=status_code,full_path=full_path)
        if record.name =="uvicorn.access" :
            (
            client_addr,
            method,
            full_path,
            http_version,
            status_code,
            ) = record.args
            log = logger.bind(app_name=os.getenv("APP_NAME"),log_type="ACCESS_LOG",client_addr=client_addr,method=method,status_code=status_code,full_path=full_path)
            log.opt(
                depth=depth,
                exception=record.exc_info,
            ).log(level,record.getMessage())
        elif record.name == "uvicorn.error":
            log.opt(
                depth=depth,
                exception=record.exc_info,
            ).log(level,record.getMessage())


class CustomizeLogger:

    @classmethod
    def make_logger(cls):

        config =cls.load_logging_config()
        logging_config = config.get('logger')

        logger = cls.customize_logging(
            logging_config.get('path') ,
            level=logging_config.get('level'),
            retention=logging_config.get('retention'),
            rotation=logging_config.get('rotation'),
            format=logging_config.get('format')
        )
        
        return logger
    
    @classmethod
    def add_handler(cls):
        config =cls.load_logging_config()
        params = config.get('slack')
        handler = NotificationHandler("slack", defaults=params)
        return handler

    @classmethod
    def customize_logging(cls,
            filepath: Path,
            level: str,
            rotation: str,
            retention: str,
            format: str
    ):
        
        logger.remove()
        logger.add(
            sys.stdout,
            enqueue=True,
            backtrace=True,
            level=level.upper(),
            format=format,
            #serialize=True
        )
        logger.add(
            str(filepath),
            rotation=rotation,
            retention=retention,
            enqueue=True,
            backtrace=True,
            level=level.upper(),
            format=format
        )

          # Send a single notification
          
        logger.add(cls.add_handler(), level="ERROR")
        logging.basicConfig(handlers=[InterceptHandler()], level=0)
        logging.getLogger("uvicorn.access").handlers = [InterceptHandler()]
        for _log in ['uvicorn',
                     'uvicorn.error',
                     'fastapi'
                     ]:
            _logger = logging.getLogger(_log)
            _logger.propagate = False
            _logger.handlers = [InterceptHandler()]
        
        return logger.bind(app_name=None, log_type=None)


    @classmethod
    def load_logging_config(cls):
        config = None
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"logging_config.json")
        with open(config_path) as config_file:
            config = json.load(config_file)
        return config



