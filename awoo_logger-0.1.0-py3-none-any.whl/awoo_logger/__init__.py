__name__ = "awoo_logger"
__version__ = "0.1.0"